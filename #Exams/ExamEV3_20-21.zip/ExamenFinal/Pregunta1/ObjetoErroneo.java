
public class ObjetoErroneo extends Exception {

}
