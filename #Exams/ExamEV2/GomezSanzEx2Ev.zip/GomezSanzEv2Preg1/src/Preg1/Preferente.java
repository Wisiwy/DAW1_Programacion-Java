//package Preg1;
//
//public class Preferente extends Pasajeros {
//
//	public Preferente(Integer pasa, boolean pref) {
//		super(pasa, pref);
//		pasa
//	}
//
//	@Override
//	public boolean pasaMax() {
//			if (this.getPasa() > 30)
//				return false;
//			else
//				return true;
//	}
//	public String pintarVag() {
//		return String.format("---(%2d):{***%2d***}", this.getId(), this.getPasa());
//
//	}
//
//	
//	
//}
