package Preg1;

public class Mercancias extends Vagon {

	private Integer carbon;
	private Integer madera;
	private Integer hierro;
	private int cont;

	public Mercancias(Integer carbon, Integer madera, Integer hierro) {
		this.carbon = carbon;
		this.madera = madera;
		this.hierro = hierro;
	}

	public Integer getCarbon() {
		
		return carbon;
	}

	public void setCarbon(Integer carbon) {
		
		do {
			if(!this.pesoMax())
				System.out.println("Peso max alcanzado. Disminuye cantidad.");
		} while (!this.pesoMax());
		this.carbon = carbon;
	}

	public Integer getMadera() {
		return madera;
	}

	public void setMadera(Integer madera) {
		do {
			if(!this.pesoMax())
				System.out.println("Peso max alcanzado. Disminuye cantidad.");
		} while (!this.pesoMax());
		this.madera = madera;
		}

	public Integer getHierro() {
		return hierro;
	}

	public void setHierro(Integer hierro) {
		do {
			if(!this.pesoMax())
				System.out.println("Peso max alcanzado. Disminuye cantidad.");
		} while (!this.pesoMax());
		this.hierro = hierro;
	}
	
	/**
	 * 
	 * @return falso si supera los 100.000
	 */
	public boolean pesoMax() {
		int sum = carbon+madera+hierro;
		if(sum>100000)
			return false;
		return true;
	};

	public String pintarVag() {
		return String.format("---(%2d):[%d,%d,%d]",this.getId(), this.carbon, this.madera, this.hierro);

	}

}
