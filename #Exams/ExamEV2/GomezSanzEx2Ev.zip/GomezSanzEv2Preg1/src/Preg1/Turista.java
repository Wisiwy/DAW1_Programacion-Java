//package Preg1;
//
//public class Turista extends Pasajeros {
//
//	public Turista( Integer pasa, boolean pref) {
//		super( pasa, pref);
//	}
//
//	@Override
//	public boolean pasaMax() {
//		if (this.getPasa() > 60)
//			return false;
//		else
//			return true;
//	}
//
//	public String pintarVag() {
//		return String.format("---(%2d):|___%2d___|", this.getId(), this.getPasa());
//
//	}
//	
//}
