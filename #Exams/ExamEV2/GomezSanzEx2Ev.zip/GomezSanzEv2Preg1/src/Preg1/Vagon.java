package Preg1;


public abstract class Vagon {
	
	private Integer id;
	public  int cont = 3;
	
	
	public Vagon() {
		this.id = cont;
		cont++;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Vagon(int id) {
		this.id = id;
	}


	public abstract String pintarVag();

}
