package Preg1;

public class PesoMaxExcepcion {

}
