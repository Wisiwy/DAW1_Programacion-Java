package Preg1;

public class Locomotora extends Vagon {

	
	public  Locomotora() {
		// TODO Auto-generated constructor stub
	};
	public String pintarVag() {
		return String.format("/ooo#88T|");

	}

}
