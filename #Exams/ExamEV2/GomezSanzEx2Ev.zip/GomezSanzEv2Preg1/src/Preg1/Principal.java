package Preg1;

import java.util.ArrayList;
import java.util.List;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Inserta la definición de la colección
		List<List<Vagon>> trenes = new ArrayList();
		trenes.add(crea());
		trenes.add(crea());

		final String[] MENU = { "Salir", "Crea Vagón", "Borra Vagón", "Ver Tren", "Simulación" };
		// Crea dos trenes en el método crea

		// de compra de productos
		int opcion = -1;
		while (opcion != 0) {
			switch (opcion) {
			case 1:// Crea vagon
				añadirVagon(trenes);
				break;
			case 2:// Borra vagon
				borrarVagon(trenes);
				break;
			case 3:// ver tren
				for (List<Vagon> tren : trenes) {
					pintaTren(tren);
				}
				break;
			case 4:// Simulación
				break;
			}
			opcion = Leer.menu(MENU);
		}

	}

	
	
	private static void borrarVagon(List<List<Vagon>> trenes) {
		int pos = elegirTren(trenes);
		List<Vagon> tren = trenes.get(pos);
		tren.remove(pos);
		
//		for (int i = 0; i < array.length; i++) {
//			
//		}
	}



	private static void añadirVagon(List<List<Vagon>> trenes) {
		int pos = elegirTren(trenes);
		List<Vagon> aux;
		aux = trenes.get(pos);
		Vagon auxVag = vagAle();
		
		aux.add(aux.size(), auxVag);
	}



	private static Vagon vagAle() {
		Vagon auxVag;
		
		int tipoVag = (int) (Math.random() * 2);
		if (tipoVag == 0) {
			int auxMad = (int) (Math.random() * 10000);
			int auxCar = (int) (Math.random() * 10000);
			int auxHie = (int) (Math.random() * 10000);
			auxVag = new Mercancias(auxCar, auxMad, auxHie);
		
		} else {
			
			Integer pasa = (int) (Math.random() * 30);
			int auxpref = (int) (Math.random() * 2);
			boolean pref= true;
			if (auxpref == 1) {
				pref = true;
				auxVag = new Pasajeros(pasa, pref);
			} else {
				pref = false;
				auxVag = new Pasajeros(pasa, pref);

			}
		}
		return auxVag;
	}



	private static int elegirTren(List<List<Vagon>> trenes) {

		
			
			for (int j = 0; j < trenes.size(); j++) {
				System.out.printf("%2d- %s",j, trenes.get(j)  );
			}
			
		
		return Leer.entero("Eliga un tren: " );
	}



	private static void pintaTren(List<Vagon> tren) {
			for (Vagon vagon : tren) {
				System.out.print(vagon.pintarVag());
				
			}
			System.out.println();
		
	}
	



	public static List<Vagon> crea() {
		// crea 2 composiciones de trenes (vagones)
		List<Vagon> tren = new ArrayList();
		int size = (int) (Math.random() * 10 +3);// tamaño tren
		//Añade locomotora
		tren.add(0, new Locomotora());
		// Añadir vagones random
		for (int i = 0; i < size; i++) {
			//Elegir y añadir tipo vagon
			int tipoVag = (int) (Math.random() * 2);
			if (tipoVag == 0) {
				int auxMad = (int) (Math.random() * 10000);
				int auxCar = (int) (Math.random() * 10000);
				int auxHie = (int) (Math.random() * 10000);
				tren.add(tren.size()-1,new Mercancias(auxCar, auxMad, auxHie));
			} else  {				
				Pasajeros aux;
				Integer pasa = (int) (Math.random() * 30);
				int auxpref = (int) (Math.random() * 2);
				boolean pref= true;
				if (auxpref == 1) {
					pref = true;
					tren.add(new Pasajeros(pasa, pref));
				} else {
					pref = false;
					tren.add(tren.size()-1,new Pasajeros(pasa, pref));

				}
			}
		}
		pintaTren(tren);
		return tren;

	}

}
