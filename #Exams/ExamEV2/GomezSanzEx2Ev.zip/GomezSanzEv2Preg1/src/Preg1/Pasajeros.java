package Preg1;

public  class Pasajeros extends Vagon {

	private Integer pasa;
	private boolean pref;
	private Integer pasaMax;
	
	private static int pasaMax1 = 30;
	private static int pasaMax2 = 620;

	public Pasajeros(Integer pasa, boolean pref) {
		
		this.pasa = pasa;
		this.pref = pref;
		if (pref)
			this.pasaMax = 30;
		else
			this.pasaMax = 60;
	}

	public Integer getPasa() {
		return pasa;
	}

	public void setPasa(Integer pasa) {
		this.pasa = pasa;
	}

	public boolean isPref() {
		return pref;
	}

	public void setPref(boolean pref) {
		this.pref = pref;
	}

	public String pintarVag() {
		if (pref)
			return String.format("---(%2d):{***%2d***}", this.getId(), this.pasa);
		else
			return String.format("---(%2d):|___%2d___|", this.getId(), this.pasa);

	}

	// Chequea que el num max de pasajeros.

}
