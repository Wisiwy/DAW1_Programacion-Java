package Preg2;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

public class LigaPokemon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Pokemon> ligasPokemon = new ArrayList<>();
		rellena(ligasPokemon);
		ligasPokemon.forEach(System.out::println);
		///////////////////////////////////////
		// .......continúa a partir de aquí
		///////////////////////////////////////

		// Crear participantes a partir de Pokemons
		List<Participante> participantes = new ArrayList();
		
		//Rellenar lista
		for (Pokemon pokemon : ligasPokemon) {
			Participante aux;
			String equi = pokemon.getEquipo();
			List<String> auxLig = pokemon.getLigas();
			for (int i = 0; i < auxLig.size(); i++) {
				String liga = pokemon.getLigas().get(i);
				double punt = pokemon.getPuntos().get(i);
				participantes.add(new Participante(pokemon,equi,liga,punt));
			}
		}
		System.out.println("-------------------Imprime PARTICIPANTES------------------------");
		System.out.println();
		participantes.forEach(System.out::println);

		
		//Crear TREEMAP PARA CADA LIGA
		
		TreeMap<String, List<Participante>> resulMap = new TreeMap(); 
		
		for (Participante participante : participantes) {
			String keyaux = participante.getLiga();
			List<Participante> partiAux;
			if(!resulMap.containsKey(keyaux)) {
				partiAux = new ArrayList();
			}else
				partiAux = resulMap.get(keyaux);

			partiAux.add(participante);
			resulMap.put(keyaux, partiAux);
		}
		
		
		//Ordenar TREEMAP
		Comparator<Participante> compPunt = (a, b) -> (int) (b.getPuntuacion() * 100) - (int) (a.getPuntuacion() * 100);
		Iterator<String> it = resulMap.keySet().iterator();
		while(it.hasNext()) {
			resulMap.get(it.next()).sort(compPunt);
			}
		System.out.println("-------------------Imprime pruebas------------------------");
		pintarTree(resulMap);
		
		//Crear lista de pokemons con las medallas
		System.out.println("Lista pokemons");
		
		String[] pokemon = { "Bulbasaur", "Venusaur", "Pikachu", "Raichu", "Squirtle", "Blastoise", "Charmander",
				"Chameleon", "Dragonite", "Snorlax", "Metapod", "Pidgeotto", "Zubat", "Psyduck", "Geodude", "Haunter",
				"Onix", "Gengar", "Drowzee", "Cubone", "Rhydon", "Gyarados", "Ditto", "Vaporeon" };
		
		List<PokeMeda> medallero = new ArrayList();
		for (int i = 0; i < pokemon.length; i++) {
			PokeMeda aux;
			medallero.add(new PokeMeda(pokemon[i]));
		}
		for (PokeMeda pokeMeda : medallero) {
			System.out.println(pokeMeda);
		}
	//Recorrer TreeMap a primeros otorgar medas
		
//		Iterator<String> it2 = resulMap.keySet().iterator();
//		while(it.hasNext()) {
//			List<Participante> auxPart =resulMap.get(it2.next());
//			for (int i = 0; i < 3; i++) {
//				Set<String> auxPoke = auxPart.get(i);
//				
//				
//			}
//				
//			}
		
//	////////////////////AQUI ME QUEDO
//		
//		1-coger la lista de pokemons 
		//2-comparalo con la lista de pokemons medallero
		// añadirle oro o lo que sea si lo contiene 
//		
//		
//		
	
	}
	



	private static void pintarTree(TreeMap<String, List<Participante>> resulMap) {
		Iterator<String> it = resulMap.keySet().iterator();
		while(it.hasNext()) {
			System.out.println();
			String auxKey = it.next();
			System.out.println(auxKey);
			List<Participante> listAux2 = resulMap.get(auxKey);
			listAux2.forEach(System.out::println);
			
			}
		
	}




	public static void rellena(List<Pokemon> a) {
		String[] ligas = { "Liga Master Ball", "Liga Escarlata", "Liga Purpura", "Liga Pokemon Go", "Liga Ultra Ball",
				"Liga Mega Ball" };
		String[] equipos = { "Alohomora", "Accio", "Brackium Emendi", "Confundus", "Engorgio", "Expecto Patronum",
				"Expelliarmus", "Lumos", "Petrificus Totalus", "Riddikulus" };
		String[] pokemon = { "Bulbasaur", "Venusaur", "Pikachu", "Raichu", "Squirtle", "Blastoise", "Charmander",
				"Chameleon", "Dragonite", "Snorlax", "Metapod", "Pidgeotto", "Zubat", "Psyduck", "Geodude", "Haunter",
				"Onix", "Gengar", "Drowzee", "Cubone", "Rhydon", "Gyarados", "Ditto", "Vaporeon" };
		String[] loc = { "Huesca", "Zaragoza", "Teruel", "Castellon", "Soria", "Toledo", "Granada", "Sevilla",
				"Palencia", "Lugo" };
		double[] puntos = { 50.5, 9.5, 10.3, 5.1, 47.5, 48. };
		Pokemon at = null;
		for (int i = 0; i < ligas.length; i++) {
			int j = 0;
			int dif = (i % 2 == 0 ? (i + 1) : i);
			while (j < 6) {
				int pos = (int) (Math.random() * 10);
				at = new Pokemon(equipos[pos], loc[pos]);
				if (!a.contains(at)) {
					a.add(at);
					Set<String> pok = new LinkedHashSet();
					while (pok.size() < 5)
						pok.add(pokemon[(int) (Math.random() * pokemon.length)]);
					at.setPokemon(pok);
				} else {
					at = a.get(a.indexOf(at));
				}
				if (at.anadeMarca(ligas[i], (puntos[i] + dif * Math.random())))
					j++;
			}
		}
	}

}
