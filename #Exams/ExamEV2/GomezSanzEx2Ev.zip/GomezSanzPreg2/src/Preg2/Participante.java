package Preg2;


public class Participante {
	private Pokemon participante;
	private String equipo;
	private String liga;
	private double puntuacion;

	public Participante(Pokemon participante, String equipo, String liga, double puntuacion) {
		this.participante = participante;
		this.equipo = equipo;
		this.liga = liga;
		this.puntuacion = puntuacion;
	}

	public Pokemon getParticipante() {
		return participante;
	}

	public void setParticipante(Pokemon participante) {
		this.participante = participante;
	}

	public String getEquipo() {
		return equipo;
	}

	public void setEquipo(String equipo) {
		this.equipo = equipo;
	}

	public double getPuntuacion() {
		return puntuacion;
	}

	public void setPuntuacion(double puntuacion) {
		this.puntuacion = puntuacion;
	}

	@Override
	public String toString() {
		return String.format("%s // liga: %s //puntuacion: %.2f",equipo, liga, puntuacion);
	}

	public String getLiga() {
		return liga;
	}

	public void setLiga(String liga) {
		this.liga = liga;
	}
	
	
	

}
