package Preg2;

public class PokeMeda {
	private String nom;
	private int oros;
	private int platas;
	private int bronces;
	
	

	@Override
	public String toString() {
		return String.format("%s \n \t oros:%2d //platas:%2d //bronces:%2d",nom,oros,platas,bronces );
	}

	public PokeMeda(String nom) {
		this.nom = nom;
		this.oros = 0;
		this.platas = 0;
		this.bronces = 0;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getOros() {
		return oros;
	}

	public void setOros(int oros) {
		this.oros = oros;
	}

	public int getPlatas() {
		return platas;
	}

	public void setPlatas(int platas) {
		this.platas = platas;
	}

	public int getBronces() {
		return bronces;
	}

	public void setBronces(int bronces) {
		this.bronces = bronces;
	}
	
	

}
